package application;

public class Calculate {

	public float calculateUnaryNumber(float number1,String operator){
		switch (operator) {
		case "FLR":
            return (float) Math.floor(number1);	
        case "CEIL":
            return (float) Math.ceil(number1);
		case "√":	
			return (float)Math.sqrt(number1);
		case "∛":
            return (float)Math.cbrt(number1); 
		case "log x":
	            return (float) Math.log10(number1);
	    case "log₂ x":
	            return (float) ((float) Math.log(number1) / Math.log(2));
		case "ln":
			return (float) Math.log(number1);
		case "N!":
			 if (number1 <= 1) return 1; 
			    
			    float result = 1;
			    for (int i = 2; i <= number1; i++) {
			        result *= i;
			    }
			    return result;
		default:
			break;
		}
		return 0;
	}
	public float calculateBinaryNumber(float number1,float number2,String operator){
		switch (operator) {
		case "+":
			return number1 + number2;
		case "-":
			return number1 - number2;
		case "*":
			return number1 * number2;
		case "/":
			if(number2==0)
				return 0;
			return number1 / number2;
		case "Mod":
			return number1 % number2;
		case "x^y":
			return (float) Math.pow(number1, number2);
		case "x + y":
			return (float) number1 + number2;
		case "xy":
			return (float) number1 * number2;
        case "%":
            if (number2 != 0) {
                return number1 % number2; 
            }
            //di pa masyadong okay
        case "∑":
        	  float sum = 1;
              for (long i = (long) number1; i <= (long) number2; i++) {
                  sum += i;
              }
              return (float) sum;
		default:
			break;
		}
		return 0;
	}
} 

 
