package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;

public class AdvanceCalculatorController {

    @FXML
    private AnchorPane AnchorPane;

    
	@FXML
	private Label result;
	
	private float number1=0;
	
	private float number2=0;
	
	private String operator="";
	
	private boolean start=true;
	
	private Calculate calculate=new Calculate();
	
	@FXML
	public void processNumber(ActionEvent event){
		if(start){
			result.setText("");
			start=false;
		}
		String value=((Button)event.getSource()).getText();
		result.setText(result.getText()+ value);
	}
	
	@FXML
	
	public void processUnaryOperator(ActionEvent event) {
		
		String value=((Button)event.getSource()).getText();
		if(!operator.isEmpty())
			return;
		
		operator = value;
		number1=Float.parseFloat(result.getText());	
		result.setText("");
		
		float output=calculate.calculateUnaryNumber(number1,operator);
		result.setText(String.valueOf(output));
		operator="";
	}
	
 
	public void processBinaryOperator(ActionEvent event) {
		String value=((Button)event.getSource()).getText();
		if(!value.equals("=")){
			if(!operator.isEmpty())
				return;
			
			operator = value;
			number1=Float.parseFloat(result.getText());			
			result.setText("");
		}else{
			if(operator.isEmpty())
				return;
			
			number2=Float.parseFloat(result.getText());
			float output=calculate.calculateBinaryNumber(number1, number2, operator);
			result.setText(String.valueOf(output));
			operator="";
		}
	}
	
	
	//Di to gumagana tumal
	public void handleSet(ActionEvent event) {
	    
	}
	
	public void handleVariableInput(ActionEvent event) {
	    Button button = (Button) event.getSource();
	    String value = button.getText();

	   
	    switch (value) {
	        case "A":
	        
	            break;
	        case "B":
	           
	            break;
	        case "C":
	          
	            break;
	        case "D":
	           
	            break;
	        default:
	          
	            System.err.println("Unexpected button value: " + value);
	            break;
	    }
	}	
	
	
	
	//Clear that shit
	public void ClearFunction(ActionEvent event){
		operator="";
		start=true;
		result.setText("");
	}
	
	//Delete one shit
    @FXML
    void delete(ActionEvent event) {
    	String Text = result.getText();
          //ichecheck kung may idedelete na text
        if (!Text.isEmpty()) {
        	// tatanggalin yung last character dun sa string
             Text = Text.substring(0, Text.length() - 1);
            
            // dito lalagay hehe
            result.setText(Text);
        }
    }
}